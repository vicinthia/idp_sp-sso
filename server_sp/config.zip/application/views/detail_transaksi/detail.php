<?php
require_once 'vendor/autoload.php';

use Dompdf\Dompdf; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Transaksi</title>

    <style>
        td {
            font-size: 12px;
            font-family: sans-serif;
        }

        h3 {
            font-size: 18px;
        }

        hr {
            border: 0;
            border-top: 2px solid;
        }

        .tabel {
            border: 1px solid black;
            border-collapse: collapse;
            padding: 5px;
        }

        th {
            font-family: sans-serif;
            font-size: 12px;
            ;
        }
    </style>
</head>

<body>
    <table>
        <tr>
            <td width="400">
                <h3>Transaksi eHotel</h3>
            </td>
            <td>
                <h3>Invoice</h3>
            </td>
        <tr>
        <tr>
            <td>Alamat : Losari Kletek,Taman, Sidoarjo</td>
        </tr>
        <tr>
            <td>Telp : 082233922011</td>
        </tr>
        <tr>
            <td>Email : vicinthia.v@gmail.com</td>
        </tr>
    </table>

    <hr>
    <br>
    <table>
        <tr>
            <td width="80">Penyewa</td>
            <td width="250"><?= $transaksi['nama_penyewa']; ?></td>

            <td> Kode Transaksi </td>
            <td><?= $transaksi['id_transaksi']; ?></td>
        </tr>

        <tr>
            <td width="80"></td>
            <td width="250"></td>

            <td width="120">Tanggal Check In</td>
            <td><?= date($transaksi['tgl']); ?></td>
            <!-- <td><?= date("h:i:s d/F/y", strtotime($transaksi['tgl'])); ?></td> -->

        </tr>

        <tr>
            <td width="80"></td>
            <td width="250"></td>

            <?php
            if ($transaksi['tgl_out'] != 0) { ?>
                <td width="120">Tanggal Check Out</td>
                <td><?= date($transaksi['tgl_out']); ?></td>
            <?php } else { ?>
                <td width="120">Tanggal Check Out </td>
                <td>Belum Check Out!</td>
            <?php }
            ?>


        </tr>
    </table> <br><br>

    <table width="550" class="tabel">
        <tr>
            <th class="tabel">Type Kamar</th>
            <th class="tabel">Lama Sewa/Hari</th>
            <th class="tabel">Sub Total</th>
        </tr>

        <tr>
            <td class="tabel"><?= $transaksi['meja']; ?></td>
            <td class="tabel"><?= $transaksi['qty']; ?></td>
            <td class="tabel"><?= "Rp." . number_format($transaksi['total']); ?></td>
        </tr>

        <tr>
            <td class="tabel" colspan="2" style="text-align: right; font-weight: bold; font-size: 14px;">Grand Total</td>
            <td class="tabel" style="font-weight: bold; font-size: 14px;"><?= "Rp." . number_format($transaksi['total']); ?></td>
        </tr>
    </table>

</body>
<script>
    window.print();

    function downloadpdf() {
        var currentHref = window.location.href;
        window.history.pushState(null, null, '/app/somepdf.pdf');
        setTimeout(() => window.location.replace(currentHref), 1000);
    }
</script>


</html>
<!-- $dompdf = new Dompdf;
$dompdf->load_html($html);
$dompdf->set_paper('A5', 'potrait');
$dompdf->render();
$dompdf->stream('Detail Transaksi', array('Attachment' => 0)) -->