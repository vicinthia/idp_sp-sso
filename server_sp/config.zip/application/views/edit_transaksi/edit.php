<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Edit</title>
</head>

<body>
    <?php
    if (!empty($this->session->flashdata('info'))) { ?>
        <div class="alert alert-success alert-dismissible fade show" role='alert'>
            <strong>Selamat! </strong><?= $this->session->flashdata('info') ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php }
    ?>
    <div class="row" style="margin-top: 40px;">
        <div class="col-md-4 offset-md-4">
            <div class="card card-primary">
                <div class="card-header">
                    <h4>Form Edit Data</h4>
                </div>
                <div class="card-body">
                    <form method="post" action="<?php echo base_url('home/update') ?>">
                        <div class="form_group">
                            <label>ID Transaksi</label>
                            <input type="text" name="id_transaksi" value="<?= $transaksi['id_transaksi'] ?>" class="form-control" readonly>

                        </div>
                        <div class="form_group">
                            <label>Nama Penyewa</label>
                            <input type="text" name="nama_penyewa" value="<?= $transaksi['nama_penyewa'] ?>" class="form-control" autocomplete="off">
                            <small><span class="text-danger"></span></small>
                        </div>
                        <div class="form_group">
                            <label>Type Kamar</label>
                            <input type="text" name="meja" value="<?= $transaksi['meja'] ?>" class="form-control" autocomplete="off">
                            <small><span class="text-danger"></span></small>
                        </div>
                        <div class="form_group">
                            <label>Lama Sewa/hari</label>
                            <input type="text" name="qty" value="<?= $transaksi['qty'] ?>" class="form-control" autocomplete="off">
                            <small><span class="text-danger"></span></small>
                        </div>
                        <div class="form_group">
                            <label>Total</label>
                            <input type="text" name="total" value="<?= $transaksi['total'] ?>" class="form-control" autocomplete="off">
                            <small><span class="text-danger"></span></small>
                        </div>
                        <br>
                        <button class="btn btn-primary btn-block" type="submit">Simpan</button>
                        <br>
                        <a href="<?php echo base_url() ?>home/halaman_pengguna" class="btn btn-danger btn-block">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body>

</html>