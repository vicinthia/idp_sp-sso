<?php
$koneksi = mysqli_connect("localhost", "root", "", "transaksi");

if (mysqli_connect_errno()) {
    echo "Koneksi gagal :" . mysqli_connect_error();
}

$id = $_GET['id_transaksi'];
$status = $_GET['status'];

$q = "update transaksi set status=$status where id_transaksi=$id";

mysqli_query($koneksi, $q);
