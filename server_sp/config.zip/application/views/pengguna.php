<!doctype html>
<html lang="en">

<head>
    <style>
        td {
            text-align: center;
            vertical-align: middle;
        }

        th {
            text-align: center;
            vertical-align: middle;
        }

        a {
            color: white;
        }
    </style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>eTicket</title>
</head>

<body>
    <div class="col-lg-12">
        <h1 class="page-header">Daftar Transaksir</h1>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-body">

                    <div class="dataTable_wrapper">
                        <div class="container">
                            <table class="table table-bordered table-striped table-hover" id="dataTables-example">

                                <form action="<?php echo base_url('home/hasil2') ?>" action="GET">
                                    <div class="form-group">
                                        <label for="cari">data yang dicari</label>
                                        <input type="text" class="form-control" id="cari" name="cari" placeholder="cari">
                                    </div>
                                    <input class="btn btn-primary" type="submit" value="Cari">
                                </form>
                                <tr>
                                    <td>No</td>
                                    <td>ID Transaksi</td>
                                    <!-- <td>Nama Penyewa</td> -->
                                    <td>Type Kamar</td>
                                    <!-- <td>Lama Sewa/Harian</td>
                                    <td>Tanggal Check In</td>
                                    <td>Tanggal Check Out</td> -->
                                    <td>Total</td>
                                    <td>Status</td>
                                    <!-- <td>Aksi</td> -->
                                </tr>

                                <?php $no = 1;
                                foreach ($data as $row) {

                                ?>
                                    <td><?php echo $no ?></td>
                                    <td><?php echo $row->id_transaksi ?></td>
                                    <!-- <td><?php echo $row->nama_penyewa ?></td> -->
                                    <td><?php echo $row->meja ?></td>
                                    <!-- <td><?php echo $row->qty ?></td>
                                    <td><?php echo date($row->tgl) ?></td>
                                    <td><?php echo ($row->tgl_out) ?></td> -->
                                    <td>Rp. <?php echo number_format($row->total) ?></td>
                                    <!-- <td>
                                        <?php
                                        if ($row->status == 1) { ?>
                                            <select name="status" class="badge badge-danger status">
                                                <option value="<?= $row->id_transaksi ?> Belum Lunas" selected>Belum Lunas</option>
                                                <option value="<?= $row->id_transaksi ?> Lunas">Lunas</option>
                                            </select>
                                        <?php } else { ?>
                                            <button class="btn btn-success btn-sm dropdown-toggle">Lunas</button>
                                        <?php } ?>
                                    </td> -->
                                    <td>
                                        <?php if ($row->status == "1") {
                                            echo ""; ?>
                                            <button class="btn btn-success">Lunas</button>
                                        <?php } else {
                                        ?>
                                            <button class="btn btn-success">Lunas</button>
                                        <?php } ?>
                                    </td>
                                    <!-- <?php
                                            if ($row->status == 0) { ?>
                                        <td>
                                            <a href="<?php echo base_url('') ?>/home/detail/<?= $row->id_transaksi ?>" class="btn btn-warning btn-sm">Detail</a>
                                        </td>
                                    <?php } else { ?>
                                        <td>
                                            <a href="<?php echo base_url('') ?>/home/detail/<?= $row->id_transaksi ?>" class="btn btn-warning btn-sm">Detail</a>
                                            <a href="<?php echo base_url('') ?>/home/edit_transaksi/<?= $row->id_transaksi ?>" class="btn btn-primary brn-sm">Edit</a>
                                        </td>
                                    <?php }
                                    ?> -->

                                    </tr>
                                <?php
                                    $no++;
                                }
                                ?>

                            </table>

                            <div class="row">
                                <div class="col">
                                    <?php echo $pagination; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>

    <script>
        $('.status').change(function() {
            var status = $(this).val();
            var kt = status.substr(0, 5);
            var stt = status.substr(5, 10);

            $.ajax({
                url: "<?= base_url('/home/update_status') ?>",
                method: "post",
                data: {
                    kt: kt,
                    stt: stt
                }
            });
            location.reload();
        });
    </script>
</body>

</html>