<?php
defined('BASEPATH') or exit('No direct script access allowed');

class H_Aug extends CI_Model
{
    public function get_select1()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-01'");
        return $query->result();
    }
    public function get_select2()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-02'");
        return $query->result();
    }
    public function get_select3()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-03'");
        return $query->result();
    }
    public function get_select4()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-04'");
        return $query->result();
    }
    public function get_select5()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-05'");
        return $query->result();
    }
    public function get_select6()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-06'");
        return $query->result();
    }
    public function get_select7()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-07'");
        return $query->result();
    }
    public function get_select8()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-08'");
        return $query->result();
    }
    public function get_select9()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-09'");
        return $query->result();
    }
    public function get_select10()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-10'");
        return $query->result();
    }
    public function get_select11()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-11'");
        return $query->result();
    }
    public function get_select12()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-12'");
        return $query->result();
    }
    public function get_select13()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-13'");
        return $query->result();
    }
    public function get_select14()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-14'");
        return $query->result();
    }
    public function get_select15()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-15'");
        return $query->result();
    }
    public function get_select16()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-16'");
        return $query->result();
    }
    public function get_select17()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-17'");
        return $query->result();
    }
    public function get_select18()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-18'");
        return $query->result();
    }
    public function get_select19()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-19'");
        return $query->result();
    }
    public function get_select20()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-20'");
        return $query->result();
    }
    public function get_select21()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-21'");
        return $query->result();
    }
    public function get_select22()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-22'");
        return $query->result();
    }
    public function get_select23()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-23'");
        return $query->result();
    }
    public function get_select24()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-24'");
        return $query->result();
    }
    public function get_select25()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-25'");
        return $query->result();
    }
    public function get_select26()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-26'");
        return $query->result();
    }
    public function get_select27()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-27'");
        return $query->result();
    }
    public function get_select28()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-28'");
        return $query->result();
    }
    public function get_select29()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-29'");
        return $query->result();
    }
    public function get_select30()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-30'");
        return $query->result();
    }
    public function get_select31()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-08-31'");
        return $query->result();
    }
}
