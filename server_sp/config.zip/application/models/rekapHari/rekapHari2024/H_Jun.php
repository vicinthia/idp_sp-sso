<?php
defined('BASEPATH') or exit('No direct script access allowed');

class H_Jun extends CI_Model
{
    public function get_select1()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-01'");
        return $query->result();
    }
    public function get_select2()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-02'");
        return $query->result();
    }
    public function get_select3()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-03'");
        return $query->result();
    }
    public function get_select4()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-04'");
        return $query->result();
    }
    public function get_select5()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-05'");
        return $query->result();
    }
    public function get_select6()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-06'");
        return $query->result();
    }
    public function get_select7()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-07'");
        return $query->result();
    }
    public function get_select8()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-08'");
        return $query->result();
    }
    public function get_select9()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-09'");
        return $query->result();
    }
    public function get_select10()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-10'");
        return $query->result();
    }
    public function get_select11()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-11'");
        return $query->result();
    }
    public function get_select12()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-12'");
        return $query->result();
    }
    public function get_select13()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-13'");
        return $query->result();
    }
    public function get_select14()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-14'");
        return $query->result();
    }
    public function get_select15()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-15'");
        return $query->result();
    }
    public function get_select16()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-16'");
        return $query->result();
    }
    public function get_select17()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-17'");
        return $query->result();
    }
    public function get_select18()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-18'");
        return $query->result();
    }
    public function get_select19()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-19'");
        return $query->result();
    }
    public function get_select20()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-20'");
        return $query->result();
    }
    public function get_select21()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-21'");
        return $query->result();
    }
    public function get_select22()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-22'");
        return $query->result();
    }
    public function get_select23()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-23'");
        return $query->result();
    }
    public function get_select24()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-24'");
        return $query->result();
    }
    public function get_select25()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-25'");
        return $query->result();
    }
    public function get_select26()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-26'");
        return $query->result();
    }
    public function get_select27()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-27'");
        return $query->result();
    }
    public function get_select28()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-28'");
        return $query->result();
    }
    public function get_select29()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-29'");
        return $query->result();
    }
    public function get_select30()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-06-30'");
        return $query->result();
    }
}
