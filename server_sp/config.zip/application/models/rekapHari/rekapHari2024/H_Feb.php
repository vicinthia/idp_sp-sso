<?php
defined('BASEPATH') or exit('No direct script access allowed');

class H_Feb extends CI_Model
{
    public function get_select1()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-01'");
        return $query->result();
    }
    public function get_select2()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-02'");
        return $query->result();
    }
    public function get_select3()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-03'");
        return $query->result();
    }
    public function get_select4()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-04'");
        return $query->result();
    }
    public function get_select5()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-05'");
        return $query->result();
    }
    public function get_select6()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-06'");
        return $query->result();
    }
    public function get_select7()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-07'");
        return $query->result();
    }
    public function get_select8()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-08'");
        return $query->result();
    }
    public function get_select9()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-09'");
        return $query->result();
    }
    public function get_select10()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-10'");
        return $query->result();
    }
    public function get_select11()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-11'");
        return $query->result();
    }
    public function get_select12()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-12'");
        return $query->result();
    }
    public function get_select13()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-13'");
        return $query->result();
    }
    public function get_select14()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-14'");
        return $query->result();
    }
    public function get_select15()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-15'");
        return $query->result();
    }
    public function get_select16()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-16'");
        return $query->result();
    }
    public function get_select17()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-17'");
        return $query->result();
    }
    public function get_select18()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-18'");
        return $query->result();
    }
    public function get_select19()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-19'");
        return $query->result();
    }
    public function get_select20()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-20'");
        return $query->result();
    }
    public function get_select21()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-21'");
        return $query->result();
    }
    public function get_select22()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-22'");
        return $query->result();
    }
    public function get_select23()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-23'");
        return $query->result();
    }
    public function get_select24()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-24'");
        return $query->result();
    }
    public function get_select25()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-25'");
        return $query->result();
    }
    public function get_select26()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-26'");
        return $query->result();
    }
    public function get_select27()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-27'");
        return $query->result();
    }
    public function get_select28()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-02-28'");
        return $query->result();
    }
}
