<?php
defined('BASEPATH') or exit('No direct script access allowed');

class H_Mar extends CI_Model
{
    public function get_select1()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-01'");
        return $query->result();
    }
    public function get_select2()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-02'");
        return $query->result();
    }
    public function get_select3()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-03'");
        return $query->result();
    }
    public function get_select4()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-04'");
        return $query->result();
    }
    public function get_select5()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-05'");
        return $query->result();
    }
    public function get_select6()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-06'");
        return $query->result();
    }
    public function get_select7()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-07'");
        return $query->result();
    }
    public function get_select8()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-08'");
        return $query->result();
    }
    public function get_select9()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-09'");
        return $query->result();
    }
    public function get_select10()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-10'");
        return $query->result();
    }
    public function get_select11()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-11'");
        return $query->result();
    }
    public function get_select12()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-12'");
        return $query->result();
    }
    public function get_select13()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-13'");
        return $query->result();
    }
    public function get_select14()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-14'");
        return $query->result();
    }
    public function get_select15()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-15'");
        return $query->result();
    }
    public function get_select16()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-16'");
        return $query->result();
    }
    public function get_select17()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-17'");
        return $query->result();
    }
    public function get_select18()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-18'");
        return $query->result();
    }
    public function get_select19()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-19'");
        return $query->result();
    }
    public function get_select20()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-20'");
        return $query->result();
    }
    public function get_select21()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-21'");
        return $query->result();
    }
    public function get_select22()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-22'");
        return $query->result();
    }
    public function get_select23()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-23'");
        return $query->result();
    }
    public function get_select24()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-24'");
        return $query->result();
    }
    public function get_select25()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-25'");
        return $query->result();
    }
    public function get_select26()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-26'");
        return $query->result();
    }
    public function get_select27()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-27'");
        return $query->result();
    }
    public function get_select28()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-28'");
        return $query->result();
    }
    public function get_select29()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-29'");
        return $query->result();
    }
    public function get_select30()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-30'");
        return $query->result();
    }
    public function get_select31()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2024-03-31'");
        return $query->result();
    }
}
