<?php
defined('BASEPATH') or exit('No direct script access allowed');

class H_Oct extends CI_Model
{
    public function get_select1()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-01'");
        return $query->result();
    }
    public function get_select2()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-02'");
        return $query->result();
    }
    public function get_select3()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-03'");
        return $query->result();
    }
    public function get_select4()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-04'");
        return $query->result();
    }
    public function get_select5()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-05'");
        return $query->result();
    }
    public function get_select6()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-06'");
        return $query->result();
    }
    public function get_select7()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-07'");
        return $query->result();
    }
    public function get_select8()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-08'");
        return $query->result();
    }
    public function get_select9()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-09'");
        return $query->result();
    }
    public function get_select10()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-10'");
        return $query->result();
    }
    public function get_select11()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-11'");
        return $query->result();
    }
    public function get_select12()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-12'");
        return $query->result();
    }
    public function get_select13()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-13'");
        return $query->result();
    }
    public function get_select14()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-14'");
        return $query->result();
    }
    public function get_select15()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-15'");
        return $query->result();
    }
    public function get_select16()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-16'");
        return $query->result();
    }
    public function get_select17()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-17'");
        return $query->result();
    }
    public function get_select18()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-18'");
        return $query->result();
    }
    public function get_select19()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-19'");
        return $query->result();
    }
    public function get_select20()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-20'");
        return $query->result();
    }
    public function get_select21()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-21'");
        return $query->result();
    }
    public function get_select22()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-22'");
        return $query->result();
    }
    public function get_select23()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-23'");
        return $query->result();
    }
    public function get_select24()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-24'");
        return $query->result();
    }
    public function get_select25()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-25'");
        return $query->result();
    }
    public function get_select26()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-26'");
        return $query->result();
    }
    public function get_select27()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-27'");
        return $query->result();
    }
    public function get_select28()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-28'");
        return $query->result();
    }
    public function get_select29()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-29'");
        return $query->result();
    }
    public function get_select30()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-30'");
        return $query->result();
    }
    public function get_select31()
    {
        $query = $this->db->query("select*from transaksi where date (tgl) = '2022-10-31'");
        return $query->result();
    }
}
